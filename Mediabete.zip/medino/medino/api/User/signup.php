<?php
include_once '../config/database.php';
include_once '../objects/user.php';
 
$database = new Database();
$db = $database->getConnection();
 
$user = new User($db);
 
// set user property values
$user->Nom = $_POST['Nom'];
$user->password = base64_encode($_POST['password']);
$user->created = date('Y-m-d H:i:s');
 
// create the user
if($user->signup()){
    $user_arr=array(
        "status" => true,
        "message" => "Successfully Signup!",
        "id" => $user->id,
        "Nom" => $user->Nom
    );
}
else{
    $user_arr=array(
        "status" => false,
        "message" => "Nom already exists!"
    );
}
print_r(json_encode($user_arr));
?>